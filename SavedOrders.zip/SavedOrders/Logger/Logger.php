<?php

namespace Davidsons\SavedOrders\Logger;

class Logger extends \Monolog\Logger
{

}
